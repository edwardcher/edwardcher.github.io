# Vim Navigation

Load navigation.css, include the dialog and trigger from example.html, then load reading-navigation.js once. No public JS API. Configure workspace anchor hrefs in the dialog. The h shortcut on the main page targets /. Adapt root-relative URLs for your deployment. Optional #reading-progress displays scroll progress. See the online API reference for keyboard controls and integration constraints. No redistribution licence assigned.
